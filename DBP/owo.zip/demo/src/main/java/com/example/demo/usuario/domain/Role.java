package com.example.demo.usuario.domain;

public enum Role {
    USER,
    ADMIN
}
